<?php $__env->startSection('title', 'Profile'); ?>

<?php $__env->startSection('content_header'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container mt-3">

    <div class="row">
        <h1>Clientes</h1>

    </div>
    <div class="row">
        <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#createUserModal">
            Afiliar Cliente
        </button>
    </div>
    <div class="row bg-white mt-3">
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Nombres</th>
                    <th>Apellidos</th>
                    <th>Telefono</th>
                    <th>Correo</th>
                    <th>Direccion</th>
                    <th>Identificacion</th>

                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $clients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $client): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($client->id); ?></td>
                    <td><?php echo e($client->names); ?></td>
                    <td><?php echo e($client->surnames); ?></td>
                    <td><?php echo e($client->phone); ?></td>
                    <td><?php echo e($client->email); ?></td>
                    <td><?php echo e($client->address); ?></td>
                    <td><?php echo e($client->identification); ?></td>

                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</div>




<!-- Modal -->
<div class="modal fade" id="createUserModal" tabindex="-1" role="dialog" aria-labelledby="createUserModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="createUserModalLabel">Afiliar Cliente</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <form action="<?php echo e(route('admin.clients.create')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="form-group">
                        <label for="name">Nombres:</label>
                        <input type="text" class="form-control" id="names" name="names" required>
                    </div>

                    <div class="form-group">
                        <label for="email">Apellidos:</label>
                        <input type="text" class="form-control" id="surnames" name="surnames" required>
                    </div>

                    <div class="form-group">
                        <label for="rol">Telefono:</label>
                        <input type="number" class="form-control" id="phone" name="phone" required>

                    </div>

                    <div class="form-group">
                        <label for="rol">Correo:</label>
                        <input type="number" class="form-control" id="email" name="email" required>

                    </div>

                    <div class="form-group">
                        <label for="rol">Direccion:</label>
                        <input type="number" class="form-control" id="address" name="address" required>

                    </div>

                    <div class="form-group">
                        <label for="rol">Tipo de identificacion:</label>
                        <select class="form-control"
                        id="id_type"
                        name="id_type"
                        >
                        <option value="CEDULA">CEDULA DE CIUDADANIA</option>
                        <option value="TARJETA">TARJETA</option>
                        <option value="PASAPORTE">PASAPORTE</option>

                        </select>
                    </div>

                    <div class="form-group">
                        <label for="rol">Identificacion:</label>
                        <input type="number" class="form-control" id="identification" name="identification" required>

                    </div>

                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Cerrar</button>
                        <button type="submit" class="btn btn-primary">Afiliar Cliente</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sistemacobranzas\resources\views/clients/index.blade.php ENDPATH**/ ?>