<?php $__env->startSection('title', 'Profile'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Profile</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <h2>Nombre: <?php echo e($user->name); ?></h2>
    <h2>Correo: <?php echo e($user->email); ?></h2>
    <h2>Rol: <?php echo e($user->role->name); ?></h2>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sistemacobranzas\resources\views/profile.blade.php ENDPATH**/ ?>